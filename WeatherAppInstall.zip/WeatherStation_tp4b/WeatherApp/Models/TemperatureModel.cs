﻿using System;

namespace WeatherApp
{
    public class TemperatureModel
    {
        public DateTime DateTime { get; set; }
        public double Temperature { get; set; }

    }
}