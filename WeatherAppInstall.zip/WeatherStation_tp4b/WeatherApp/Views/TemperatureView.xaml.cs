﻿using System.Windows.Controls;

namespace WeatherApp.Views
{
    /// <summary>
    /// Interaction logic for TemperatureView.xaml
    /// </summary>
    public partial class TemperatureView : UserControl
    {
        public TemperatureView()
        {
            InitializeComponent();
        }
    }
}
